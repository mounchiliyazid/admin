                                Description du Site WEB

                                     OUTILS
Outils de programmation:

 IDE:Visual Studio Code( pour le codage du Site Web)

Outils de modelisation :

 PowerAMC v.15.1 ( pour la coception du diagramme de classe et la génération du script de la base de données)

Outils de gestion des BD :
VScode ( pour la  modification du script de la BD)
postgreSQL V.15.1 ( SGBD pour créer la BD)

                                    LANGUAGES
LANGUGE DE programmation
php v.8.x