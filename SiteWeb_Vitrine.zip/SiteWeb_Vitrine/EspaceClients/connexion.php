<?php
$host = 'localhost';
$port = '5432';
$dbname ='Enterprise_db';
$user = 'postgres';
$pwd = '1234';

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user pwd=$pwd");
if(!$conn){
    echo "erreur de connexion";
}else{
    echo "reussi";
}
pg_close($conn);
?> 